﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager thismanager;
    
    public Text Txt_Coin;
    public int Score;

    // Start is called before the first frame update
    void Start()
    {
        thismanager = this;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

     public void updateCoins()
    {
        Score += 10;
        Txt_Coin.text = "Coins =" + Score;
    }
}
   

